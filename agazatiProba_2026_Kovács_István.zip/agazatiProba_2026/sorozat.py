import random
lista = []
def eredmenyek():
    szamlalo = 0
    while szamlalo < 7:
        lista.append(random.randint(-2,5))
        szamlalo += 1
    szamlalo = 0
    szoveg = ""
    while szamlalo < 7:
        szoveg = szoveg+str(lista[szamlalo])
        if szamlalo != 6:
            szoveg = szoveg+";"
        szamlalo += 1
    print(f"II/A,B:\n{szoveg}")

def sikertelen(lista):
    szamlalo = 0
    szovegszamlalo = 0
    while szamlalo < 7:
        if lista[szamlalo] < 0:
            szovegszamlalo += 1
        szamlalo += 1
    print(f"II/C, D:\n0A sikertelen próbálkozások száma: {szovegszamlalo}")

eredmenyek()
sikertelen(lista)