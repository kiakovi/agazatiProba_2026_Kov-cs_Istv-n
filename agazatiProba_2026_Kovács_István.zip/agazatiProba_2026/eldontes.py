def ertekeles():
    tanora = int(input("I/A, B:\nAdd meg a heti tanulással töltött órák számát! "))
    print(f"{tanora}")
    if 0 < tanora < 4:
        print("Nem elegendő felkészülés.")
    elif 5 < tanora < 9:
        print("Megfelelő felkészülés.")
    elif 10 <= tanora:
        print("Kiemelkedő szorgalom.")
    elif 0 > tanora:
        print("I/C:\nHibás adat.")
